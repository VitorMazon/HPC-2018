project: fdict
version: 0.6.0
summary: Documentation of fortran type-free variable and dictionary
src_dir: sources
author: Nick R. Papior
github: https://github.com/zerothi
year: 2015-2017
project_github: https://github.com/zerothi/fdict
project_download: https://github.com/zerothi/fdict/releases
output_dir: ./documentation
md_base_dir: ./docs
search: true
graph: true
search: true
coloured_edges: true
proc_internals: false
display: public
